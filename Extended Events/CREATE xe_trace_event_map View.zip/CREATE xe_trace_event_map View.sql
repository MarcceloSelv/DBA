USE [sqladmin]
GO

/*****************************************************************************
*   Object Name: xe_trace_event_map 
*   Database:  sqladmin
*
*   Summary: Creates a mapping view for Extended Events to Trace Events.
*
*   Date: September 16, 2010 
*
*   SQL Server Versions:
*         2008, 2008 R2
*         
******************************************************************************
*   Copyright (C) 2010 Jonathan M. Kehayias
*   All rights reserved. 
*
*   For more scripts and sample code, check out 
*      http://sqlblog.com/blogs/jonathan_kehayias
*
*   You may alter this code for your own *non-commercial* purposes. You may
*   republish altered code as long as you include this copyright and give 
*	due credit. 
*
*
*   THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
*   ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
*   TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
*   PARTICULAR PURPOSE. 
*
******************************************************************************/

CREATE VIEW xe_trace_event_map
AS
SELECT 'Deprecation' AS TraceCategory, 'Deprecation Announcement' AS TraceEvent, 'sqlserver' AS PackageName, 'deprecation_announcement' AS XEEventName
UNION ALL SELECT 'Deprecation', 'Deprecation Final Support', 'sqlserver', 'deprecation_final_support'
UNION ALL SELECT 'Errors and Warnings', 'ErrorLog', 'sqlserver', 'errorlog_written'
UNION ALL SELECT 'Errors and Warnings', 'EventLog', 'sqlserver', 'error_reported'
UNION ALL SELECT 'Errors and Warnings', 'Exception', 'sqlos', 'exception_ring_buffer_recorded'
UNION ALL SELECT 'Errors and Warnings', 'User Error Message', 'sqlserver', 'error_reported'
UNION ALL SELECT 'Full text', 'FT:Crawl Aborted', 'sqlserver', 'error_reported'
UNION ALL SELECT 'Locks', 'Deadlock graph', 'sqlserver', 'xml_deadlock_report'
UNION ALL SELECT 'Locks', 'Lock:Acquired', 'sqlserver', 'lock_acquired'
UNION ALL SELECT 'Locks', 'Lock:Deadlock', 'sqlserver', 'lock_deadlock'
UNION ALL SELECT 'Locks', 'Lock:Released', 'sqlserver', 'lock_released'
UNION ALL SELECT 'Stored Procedures', 'RPC Output Parameter', 'sqlserver', 'rpc_completed'
UNION ALL SELECT 'Stored Procedures', 'RPC:Completed', 'sqlserver', 'rpc_completed'
UNION ALL SELECT 'Stored Procedures', 'RPC:Starting', 'sqlserver', 'rpc_starting'
UNION ALL SELECT 'Stored Procedures', 'SP:Completed', 'sqlserver', 'module_end'
UNION ALL SELECT 'Stored Procedures', 'SP:Starting', 'sqlserver', 'module_start'
UNION ALL SELECT 'Stored Procedures', 'SP:StmtCompleted', 'sqlserver', 'sp_statement_completed'
UNION ALL SELECT 'Stored Procedures', 'SP:StmtStarting', 'sqlserver', 'sp_statement_starting'
UNION ALL SELECT 'TSQL', 'SQL:StmtCompleted', 'sqlserver', 'sql_statement_completed'
UNION ALL SELECT 'TSQL', 'SQL:StmtStarting', 'sqlserver', 'sql_statement_starting'
UNION ALL SELECT 'Locks', 'Lock:Timeout', 'sqlserver', 'locks_lock_timeouts'
UNION ALL SELECT 'Locks', 'Lock:Timeout (timeout > 0)', 'sqlserver', 'locks_lock_timeout_greater_than_0'
UNION ALL SELECT 'User configurable', 'UserConfigurable', 'sqlserver', 'user_settable'
--UNION ALL SELECT 'User configurable', 'UserConfigurable:1', 'sqlserver', 'user_settable'
--UNION ALL SELECT 'User configurable', 'UserConfigurable:2', 'sqlserver', 'user_settable'
--UNION ALL SELECT 'User configurable', 'UserConfigurable:3', 'sqlserver', 'user_settable'
--UNION ALL SELECT 'User configurable', 'UserConfigurable:4', 'sqlserver', 'user_settable'
--UNION ALL SELECT 'User configurable', 'UserConfigurable:5', 'sqlserver', 'user_settable'
--UNION ALL SELECT 'User configurable', 'UserConfigurable:6', 'sqlserver', 'user_settable'
--UNION ALL SELECT 'User configurable', 'UserConfigurable:7', 'sqlserver', 'user_settable'
--UNION ALL SELECT 'User configurable', 'UserConfigurable:8', 'sqlserver', 'user_settable'
--UNION ALL SELECT 'User configurable', 'UserConfigurable:9', 'sqlserver', 'user_settable'
UNION ALL SELECT 'Stored Procedures', 'SP:Recompile', 'sqlserver', 'sp_statement_starting'
UNION ALL SELECT 'TSQL', 'SQL:StmtRecompile', 'sqlserver', 'sql_statement_starting'

GO

SELECT  * 
FROM sqladmin.dbo.trace_xe_event_map
ORDER BY TraceCategory, TraceEvent