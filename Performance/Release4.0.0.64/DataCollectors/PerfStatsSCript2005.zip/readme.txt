These are predefined sqldiag xml configuration file you can use with SQLDiag.exe tool shipped with SQL Server 2005.
associated batch files help you launch them automatically.

SQLDiagPerfStats_Trace.XML:  collecting performance statistics and profiler trace
SQLDiagPerfStats_NoTrace.XML: collecting performance statistics but without profiler trace.
SQLDiagReplay.xml: collecting profiler trace events used for readtrace reply.  It also collect performance statistics.